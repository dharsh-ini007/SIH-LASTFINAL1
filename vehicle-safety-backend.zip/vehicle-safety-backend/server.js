const db = require("./firebase");
const express = require("express");
const cors = require("cors");
require("dotenv").config();

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

const PORT = process.env.PORT || 3000;

// Temporary storage
// Later we will replace this with Firebase Firestore.
const accidents = [];
const emergencyRequests = [];

// ==========================================
// TEST API
// ==========================================

app.get("/", (req, res) => {
    res.json({
        success: true,
        message: "Vehicle Safety Backend is running"
    });
});

app.get("/api/test", (req, res) => {
    res.json({
        success: true,
        message: "Backend connection successful"
    });
});
app.get("/api/telemetry", (req, res) => {
    res.json({
        temperature: 34.2,
        voltage: 391.5,
        current: -12.4,
        soc: 71
    });
});

// ==========================================
// ACCIDENT DETECTED
// ==========================================

app.post("/api/accident", (req, res) => {

    const {
        deviceId,
        latitude,
        longitude,
        speed,
        tilt,
        impact
    } = req.body;

    const accident = {
        accidentId: "ACC-" + Date.now(),
        deviceId: deviceId || "UNKNOWN",
        latitude: latitude || null,
        longitude: longitude || null,
        speed: speed || null,
        tilt: tilt || null,
        impact: impact || null,
        status: "ACCIDENT_DETECTED",
        detectedAt: new Date().toISOString()
    };

    accidents.push(accident);
    startEmergencyTimer(accident);

    console.log("\n🚨 ACCIDENT DETECTED");
    console.log(accident);

    res.json({
        success: true,
        message: "Accident data received",
        accident: accident,
        nextStep: "Ask user: Are you okay?"
    });
});

// ==========================================
// USER RESPONSE
// ==========================================

app.post("/api/accident/:accidentId/response", (req, res) => {

    const { accidentId } = req.params;
    const { response } = req.body;

    const accident = accidents.find(
        item => item.accidentId === accidentId
    );

    if (!accident) {
        return res.status(404).json({
            success: false,
            message: "Accident not found"
        });
    }

    if (response === "YES") {

        accident.status = "USER_OKAY";
        accident.userResponse = "YES";
        accident.respondedAt = new Date().toISOString();

        console.log("✅ User responded: I am okay");

        return res.json({
            success: true,
            message: "Emergency process cancelled",
            accident: accident
        });
    }

    if (response === "NO") {

        accident.status = "USER_NEEDS_HELP";
        accident.userResponse = "NO";
        accident.respondedAt = new Date().toISOString();

        console.log("🚨 User needs help");

        return createEmergencyRequest(accident, res);
    }

    res.status(400).json({
        success: false,
        message: "Response must be YES or NO"
    });
});

// ==========================================
// TWO-MINUTE TIMEOUT
// ==========================================

function startEmergencyTimer(accident) {

    console.log(
        `⏳ Waiting 2 minutes for user response for ${accident.accidentId}`
    );

    setTimeout(() => {

        // Find latest accident information
        const currentAccident = accidents.find(
            item => item.accidentId === accident.accidentId
        );

        if (!currentAccident) return;

        // If user hasn't responded
        if (!currentAccident.userResponse) {

            currentAccident.status = "NO_RESPONSE";

            console.log(
                `⏰ No response for ${currentAccident.accidentId}`
            );

            createEmergencyRequestWithoutResponse(currentAccident);
        }

    }, 2 * 60 * 1000);
}

// ==========================================
// CREATE AMBULANCE REQUEST
// ==========================================

function createEmergencyRequest(accident, res) {

    const emergency = {
        emergencyId: "EMG-" + Date.now(),
        accidentId: accident.accidentId,

        latitude: accident.latitude,
        longitude: accident.longitude,

        requestStatus: "AMBULANCE_REQUESTED",

        reason: accident.userResponse === "NO"
            ? "User requested help"
            : "No response within 2 minutes",

        requestedAt: new Date().toISOString(),

        ambulanceService: "NEARBY_REGISTERED_AMBULANCE"
    };

    emergencyRequests.push(emergency);

    accident.status = "AMBULANCE_REQUESTED";

    console.log("\n🚑 AMBULANCE REQUEST CREATED");
    console.log(emergency);

    if (res) {
        return res.json({
            success: true,
            message: "Request sent to registered ambulance service",
            emergency: emergency
        });
    }
}

// Used when 2-minute timer expires
function createEmergencyRequestWithoutResponse(accident) {

    const emergency = {
        emergencyId: "EMG-" + Date.now(),
        accidentId: accident.accidentId,

        latitude: accident.latitude,
        longitude: accident.longitude,

        requestStatus: "AMBULANCE_REQUESTED",

        reason: "No user response within 2 minutes",

        requestedAt: new Date().toISOString(),

        ambulanceService: "NEARBY_REGISTERED_AMBULANCE"
    };

    emergencyRequests.push(emergency);

    accident.status = "AMBULANCE_REQUESTED";

    console.log("\n🚑 2 MINUTES COMPLETED");
    console.log("📞 Ambulance request should now be sent");
    console.log(emergency);
}

// ==========================================
// VIEW ACCIDENT HISTORY
// ==========================================

app.get("/api/accidents", (req, res) => {

    res.json({
        success: true,
        count: accidents.length,
        accidents: accidents
    });
});

// ==========================================
// VIEW EMERGENCY REQUEST HISTORY
// ==========================================

app.get("/api/emergencies", (req, res) => {

    res.json({
        success: true,
        count: emergencyRequests.length,
        emergencies: emergencyRequests
    });
});

// ==========================================
// START SERVER
// ==========================================

app.listen(PORT, () => {
    console.log("==========================================");
    console.log("VEHICLE SAFETY BACKEND");
    console.log("==========================================");
    console.log(`Server running on http://localhost:${PORT}`);
    console.log("==========================================");
});